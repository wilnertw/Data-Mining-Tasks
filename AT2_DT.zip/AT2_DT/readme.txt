JARRED LAZARUS (BI20110158)

Since I am using a different dataset from my team, I seperate my "abalone.csv" from my team.

Added "Class" attribute, categorical type which contains 3 categories:
- Young
- Adult
- Old

That is all.